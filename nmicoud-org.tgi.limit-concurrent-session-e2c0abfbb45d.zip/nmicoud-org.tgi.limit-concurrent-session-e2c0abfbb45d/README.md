# README #

Please refer to [http://wiki.idempiere.org/en/Plugin:_Limit_Concurrent_Sessions](http://wiki.idempiere.org/en/Plugin:_Limit_Concurrent_Sessions)